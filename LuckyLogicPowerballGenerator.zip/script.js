document.getElementById('generateBtn').addEventListener('click', function() {
  let numbers = [];
  while (numbers.length < 5) {
    let num = Math.floor(Math.random() * 69) + 1;
    if (!numbers.includes(num)) {
      numbers.push(num);
    }
  }
  let powerball = Math.floor(Math.random() * 26) + 1;
  document.getElementById('powerballNumbers').innerHTML = `
    Numbers: ${numbers.sort((a, b) => a - b).join(', ')} <br>
    Powerball: ${powerball}
  `;
});